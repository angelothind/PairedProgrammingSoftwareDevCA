To run the test suite you must be using JUnit 5.
Use your preferred IDE (I used VSCode), to run JUnit Jupiter.
To do this in VSCode you simply open the folder where the files are located and make sure you have the java extension pack installed.
Then go to the testing tab and click "enable java tests" and select JUnit Jupiter (JUnit 5).
It will then automatically load the tests on the side bar after some buffering.
At this point all you need to do is click the small "run" icon by the file name and the tests will run.