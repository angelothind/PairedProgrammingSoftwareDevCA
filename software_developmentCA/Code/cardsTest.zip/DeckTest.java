import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

class DeckTest {
    @Test
    public void getDeckIdTest(){
        // creating decks with a variety of ids
        Deck testDeck1 = new Deck(1);
        Deck testDeck2 = new Deck(0);
        Deck testDeck3 = new Deck(1000);
        Deck testDeck4 = new Deck(-100);

        assertEquals(1,testDeck1.getDeckId());
        assertEquals(0,testDeck2.getDeckId());
        assertEquals(1000,testDeck3.getDeckId());
        assertEquals(-100,testDeck4.getDeckId());
    }

    // you cannot test addCardTest or getDeck without using the other.
    @Test
    public void addCardTest(){
        // creating mock deck and cards
        Deck testDeck1 = new Deck(1);
        Card card1 = new Card(0);
        Card card2 = new Card(1000);
        Card card3 = new Card(-100);
        Card card4 = new Card(1);

        // checking if a variety of cards can be added to one deck
        testDeck1.addCard(card1);
        testDeck1.addCard(card2);
        testDeck1.addCard(card3);
        testDeck1.addCard(card4);
        ArrayList<Card> expectedOutput = new ArrayList<>();
        expectedOutput.add(card1);
        expectedOutput.add(card2);
        expectedOutput.add(card3);
        expectedOutput.add(card4);
        assertEquals(expectedOutput, testDeck1.getDeck());

        // check if multiple decks can exist and be added to without affecting the others
        Deck testDeck2 = new Deck(2);
        testDeck2.addCard(card1);
        ArrayList<Card> expectedOutput2 = new ArrayList<>();
        expectedOutput2.add(card1);
        assertEquals(expectedOutput2, testDeck2.getDeck());
        assertEquals(expectedOutput, testDeck1.getDeck());

        // checking if the same card can be added to the same deck
        testDeck1.addCard(card1);
        expectedOutput.add(card1);
        assertEquals(expectedOutput, testDeck1.getDeck());
    }

    @Test
    public void getDeckTest(){
        // creating mock decks with cards
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Card card5 = new Card(1);
        Card card6 = new Card(2);
        Card card7 = new Card(3);
        Card card8 = new Card(4);
        Deck testDeck1 = new Deck(1);
        
        // checking basic functionality of returning a simple deck with unique numbers
        testDeck1.addCard(card1);
        testDeck1.addCard(card2);
        testDeck1.addCard(card3);
        testDeck1.addCard(card4);
        ArrayList<Card> expectedOutput = new ArrayList<>();
        expectedOutput.add(card1);
        expectedOutput.add(card2);
        expectedOutput.add(card3);
        expectedOutput.add(card4);
        assertEquals(expectedOutput, testDeck1.getDeck());

        // checking if can store cards with matching numbers
        testDeck1.addCard(card5);
        testDeck1.addCard(card6);
        testDeck1.addCard(card7);
        testDeck1.addCard(card8);
        expectedOutput.add(card5);
        expectedOutput.add(card6);
        expectedOutput.add(card7);
        expectedOutput.add(card8);
        assertEquals(expectedOutput, testDeck1.getDeck());

        // getting an empty deck
        Deck testDeck2 = new Deck(0);
        ArrayList<Card> expectedOutput2 = new ArrayList<>();
        assertEquals(expectedOutput2, testDeck2.getDeck());

        // checking if the same card can be added to the same deck has already been tested in addCardTest()
    }

    @Test
    public void removeCardTest(){
        // creating mock decks with cards to remove
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Deck testDeck1 = new Deck(1);
        testDeck1.addCard(card1);
        testDeck1.addCard(card2);
        testDeck1.addCard(card3);
        testDeck1.addCard(card4);
        
        // removing from a simple deck
        assertEquals(card1, testDeck1.removeCard());

        // removing multiple cards in a row
        assertEquals(card2, testDeck1.removeCard());

        // removing from an empty deck
        Deck testDeck2 = new Deck(2);
        assertEquals(null, testDeck2.removeCard());
    }
}