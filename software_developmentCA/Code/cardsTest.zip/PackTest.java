import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

public class PackTest {
    // similar to Hand and Deck you cannot test addCard without using getCards
    @Test
    public void addCardTest(){
        // creating mock cards and pack
        Card card1 = new Card(1);
        Card card2 = new Card(1000);
        Card card3 = new Card(-100);
        Card card4 = new Card(0);
        Pack pack1 = new Pack();

        // adding a variety of cards
        pack1.addCard(card1);
        pack1.addCard(card2);
        pack1.addCard(card3);
        pack1.addCard(card4);
        ArrayList<Card> expectedOutput = new ArrayList<>();
        expectedOutput.add(card1);
        expectedOutput.add(card2);
        expectedOutput.add(card3);
        expectedOutput.add(card4);
        assertEquals(expectedOutput, pack1.getPack());
    }

    @Test
    public void getPackTest(){
        // creating mock cards and hand
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Pack pack1 = new Pack();

        // check with a simple Pack
        pack1.addCard(card1);
        pack1.addCard(card2);
        pack1.addCard(card3);
        pack1.addCard(card4);
        ArrayList<Card> expectedOutput = new ArrayList<>();
        expectedOutput.add(card1);
        expectedOutput.add(card2);
        expectedOutput.add(card3);
        expectedOutput.add(card4);
        assertEquals(expectedOutput, pack1.getPack());

        // checking with complex cards
        Card card5 = new Card(2000);
        Card card6 = new Card(-3);
        Card card7 = new Card(1);
        Card card8 = new Card(0);
        Pack pack2 = new Pack();
        pack2.addCard(card5);
        pack2.addCard(card6);
        pack2.addCard(card7);
        pack2.addCard(card8);
        ArrayList<Card> expectedOutput2 = new ArrayList<>();
        expectedOutput2.add(card5);
        expectedOutput2.add(card6);
        expectedOutput2.add(card7);
        expectedOutput2.add(card8);
        assertEquals(expectedOutput2, pack2.getPack());

        // checking with multiple of the same card in one Pack (this checks same values as well)
        Pack pack3 = new Pack();
        pack3.addCard(card1);
        pack3.addCard(card2);
        pack3.addCard(card3);
        pack3.addCard(card1);
        ArrayList<Card> expectedOutput3 = new ArrayList<>();
        expectedOutput3.add(card1);
        expectedOutput3.add(card2);
        expectedOutput3.add(card3);
        expectedOutput3.add(card1);
        assertEquals(expectedOutput3, pack3.getPack());

        // checking with an empty Pack
        Pack pack4 = new Pack();
        ArrayList<Card> expectedOutput4 = new ArrayList<>();
        assertEquals(expectedOutput4, pack4.getPack());
    }

    @Test
    public void removeCardTest(){
        // making mock cards and hands
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Pack pack1 = new Pack();
        pack1.addCard(card1);
        pack1.addCard(card2);
        pack1.addCard(card3);
        pack1.addCard(card4);

        // checking to see if removing a card works
        assertEquals(card4, pack1.removeCard());

        // checking to see if you can remove an item from an empty list or out of index range
        Pack Pack2 = new Pack();
        assertEquals(null, Pack2.removeCard());
    }
}
