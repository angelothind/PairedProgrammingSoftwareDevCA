import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

// main class where game is run.
public class CardGame extends Thread {
    // global attributes
    static ArrayList<Player> players = new ArrayList<>();
    static ArrayList<File> outputFiles = new ArrayList<>();

    public static void main(String[] args) {
        // getting number of players
        Scanner scanner = new Scanner(System.in);
        int numberOfPlayers = 0;
        boolean validInput = false;
        // looping until a valid number of players are put in.
        while (!validInput) {
            System.out.print("Enter how many players you would like: ");
            if (scanner.hasNextInt()) {
                numberOfPlayers = scanner.nextInt();
                validInput = true;
            } else {
                System.out.println("That's not a valid integer. Please try again.");
                scanner.next();
            }
        }

        // list of decks 
        ArrayList<Deck> decks = new ArrayList<>();
        // creating deck objects
        for (int i = 1; i <= numberOfPlayers; i++) {
            // creating deck object and adding it to list of decks
            decks.add(new Deck(i));
        }

        // Create players
        for (int i = 1; i <= numberOfPlayers; i++) {
            // finding the deck ids for each player
            int disCardDeck = (i + 1 > numberOfPlayers) ? 1 : i + 1;
            // creating player object and adding it to list of players
            players.add(new Player(i, decks.get(i - 1), decks.get(disCardDeck - 1), new Hand()));
        }
        scanner.nextLine();

        // loop until user gives a valid input for pack file
        Pack pack = new Pack();
        validInput = false;
        while (!validInput){
            try{
                System.out.println("Enter pack name:");
                String filePath = scanner.nextLine();
                pack = createPack(filePath);
                validInput = validatePack(pack);
            } catch (FileNotFoundException e){
                System.out.println("Invalid pack enter another, fileNotFoundException.");
            } catch (IOException e){
                System.out.println("Invalid pack, IOException.");
            }
        }
        scanner.close();

        // deal initial hand in round robin fashion
        for(int x=1; x <= 4; x++){
            for(int y=0; y<numberOfPlayers; y++){
                players.get(y).getHand().addCard(pack.removeCard());
            }
        }

        // deal decks in round robin fashion
        for(int x=1; x <= 4; x++){
            for(int y=0; y<numberOfPlayers; y++){
                decks.get(y).addCard(pack.removeCard());
            }
        }

        // creating a stopping point for players when they finish their turn
        CyclicBarrier barrier = new CyclicBarrier(players.size(), () -> {
            // This task is executed when all threads reach the barrier
            System.out.println("All players have finished their turn. Proceeding to next round.");
        });
        
        String currentDir = System.getProperty("user.dir");
        gameStart:
        // creating a thread and output file for each player
        for (Player player : players) {
            // setting up output files
            // create file
            File file = new File(currentDir, "player " + player.getPreference() + "_output.txt");
            outputFiles.add(file);

            // clearing the file
            try (PrintWriter writer = new PrintWriter(file)) {
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            logCurrentHand(player);

            // checking if any of the players have won before the rounds start
            if (player == players.getLast()){
                // checks if any player have won before another round starts
                Object[] gameEndArray = hasPlayerWon();
                Boolean boolObject = (Boolean) gameEndArray[0];
                boolean gameOver = boolObject;
                if (gameOver) {
                    for (Player insidePlayer : players){
                        endGame(insidePlayer, gameEndArray);
                    }
                    break gameStart;
                }
            }

            // creating threads
            Thread playerThread = new Thread(() -> {
                // gameloop for each player
                // Retrieve and cast the object back to Boolean
                boolean gameOver = false;
                outerLoop:
                while(!gameOver) {
                    // draws, discards and logs the actions in one atomic method.
                    gameLoop(player);

                    // makes all players wait until everyone has finished their turn
                    try {
                        barrier.await();
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    } catch (BrokenBarrierException e) {
                        throw new RuntimeException(e);
                    }

                    // checks if any player have won before another round starts
                    Object[] gameEndArray = hasPlayerWon();
                    Boolean boolObject = (Boolean) gameEndArray[0];
                    gameOver = boolObject;

                    // return player who has won when game ends
                    if (gameOver) {
                        endGame(player, gameEndArray);
                        break outerLoop;
                    }
                    
                }
            });
            playerThread.start();
        }
    }
    
    // method to read each line of the pack file and add each value as a card (also validates that each line is an int)
    private static Pack createPack(String filePath) throws FileNotFoundException, IOException{
        Pack pack = new Pack();

        // trying to select file given
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;
        // looping through each line and assigning a card of the value given
        while ((line = br.readLine()) != null) {
            int value = Integer.parseInt(line);
            pack.addCard(new Card(value));
        }
        br.close();
        return pack;
    }

    // method to take a given pack and check the validity of the pack (it's the right size and each player can win)
    private static Boolean validatePack(Pack pack){
        boolean validInput = true;
        ArrayList<Card> cards = pack.getPack();
        // counting if the pack contains the min number of cards for each player to win
        // creating a counter for each player
        int[] counters = new int[players.size()];
        for (int i = 0; i > players.size()-1; i++){
            counters[i] = 0;
        }

        // looping through each card and incrementing the counter for the corresponding player if preferred value matches card value
        for (Card card : cards){
            // looping through each player to see if preferred value matches
            for (Player player : players){
                int playerPreference = player.getPreference();
                if (playerPreference == card.getValue()){
                    counters[playerPreference - 1]++;
                }
            }
        }

        // looping through each counter and checking if any of them are less than 4
        for (int counter : counters){
            if (counter < 4){
                validInput = false;
                System.out.println("Not all players can win, therefore the pack is invalid.");
            }
        }

        // check if the total number of cards is 8n
        if (cards.size() != (8*players.size())){
            validInput = false;
        }

        return validInput;
    }

    // method which discards a card to the discard deck and returns said card for a given player
    private static Card playerDiscards(Player player){
        Card discardedCard = player.discard();
        player.getDiscardDeck().addCard(discardedCard);
        return discardedCard;
    }

    private static Card playerDraws(Player player){
        Card drawnCard = player.getDrawDeck().removeCard();
        player.draw(drawnCard);
        return drawnCard;
    }

    private static Object[] hasPlayerWon(){
        Object[] output = new Object[2];
        output[0] = false;
        for(Player player: players){
            if(player.hasWon()){
                output[0] = true;
                output[1] = player;
            }
        }
        return output;
    }

    private static void logCurrentHand(Player player){
        // getting current players hands cards
        ArrayList<Card> handCards = player.getHand().getCards();

        // getting the value of each card
        int[] cardValues = new int[4];
        for (int i = 0; i < 4; i++){
            cardValues[i] = handCards.get(i).getValue();
        }

        // formatting into a string
        String handOutputString = "";
        for (int value : cardValues){
            handOutputString += value + " ";
        }

        // getting file
        File file = outputFiles.get(player.getPreference()-1);

        // Try to write to the file
        try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
            writer.println("Player" + player.getPreference() + "'s current hand is " + handOutputString);
        } catch (Exception e) {
            System.out.println("failed to write to the file");
        }
    }

    // logs last drawn card
    private static void logDrawnCard(Player player){
        // getting current players hands cards
        ArrayList<Card> handCards = player.getHand().getCards();

        // getting last card as that is the last added card to the hand
        Card drawnCard = handCards.getLast();
        int value = drawnCard.getValue();
        
        // getting file
        File file = outputFiles.get(player.getPreference()-1);

        // Try to write to the file
        try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
            writer.println("Player" + player.getPreference() + " drew the card " + value + ".");
        } catch (Exception e) {
            System.out.println("failed to write to the file");
        }
    }

    // logs last discarded card
    private static void logDisCard(Player player){
        // getting current players hands cards
        ArrayList<Card> discardDeckCards = player.getDiscardDeck().getDeck();

        // getting last card that was added to the discard deck
        Card disCard = discardDeckCards.getLast();
        int value = disCard.getValue();
        
        // getting file
        File file = outputFiles.get(player.getPreference()-1);

        // Try to write to the file
        try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
            writer.println("Player" + player.getPreference() + " discarded the card " + value + ".");
        } catch (Exception e) {
            System.out.println("failed to write to the file");
        }   
    }

    // logs which player won, they players exiting and the final hands
    private static void logGameEnd(Player player, Player winningPlayer){
        // getting file
        File file = outputFiles.get(player.getPreference()-1);
        int playerPreference = player.getPreference();
        int winningPlayerPreference = winningPlayer.getPreference();
        
        // log informed that another player has won
        if (playerPreference == winningPlayerPreference){
            // writing this player has won
            try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
                writer.println("Player" + playerPreference + " wins.");
            } catch (Exception e) {
                System.out.println("failed to write to the file");
            }
        } else {
            // telling other players which player has won
            try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
                writer.println("Player" + winningPlayerPreference + " has informed player" + playerPreference + " that player" + winningPlayerPreference + " has won.");
            } catch (Exception e) {
                System.out.println("failed to write to the file");
            }
        }

        // getting current players hands cards
        ArrayList<Card> handCards = player.getHand().getCards();

        // getting the value of each card
        int[] cardValues = new int[4];
        for (int i = 0; i < 4; i++){
            cardValues[i] = handCards.get(i).getValue();
        }

        // formatting into a string
        String handOutputString = "";
        for (int value : cardValues){
            handOutputString += value + " ";
        }

        // log exiting and final hand
        try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
            writer.println("Player" + playerPreference + " exits.");
            writer.println("Player" + playerPreference + " final hand: " + handOutputString);
        } catch (Exception e) {
            System.out.println("failed to write to the file");
        }
    }

    // Synchronized static method
    private static synchronized void gameLoop(Player player) {
        playerDraws(player);
        logDrawnCard(player);
        playerDiscards(player);
        logDisCard(player);
        logCurrentHand(player);
    }

    // prints the winnning player once and logs the end of the game
    private static void endGame(Player player, Object[] gameEndArray){
        Player winningPlayer = (Player) gameEndArray[1];
        if (winningPlayer == player){
            System.out.println("Player " + winningPlayer.getPreference() + " wins");
        }
        logGameEnd(player, winningPlayer);
    }
}