// interface to be implemented by all objects that hold a number of cards apart from hands ie, packs and decks.
public interface CardCollections {
    void addCard(Card card);
    Card removeCard();
}
