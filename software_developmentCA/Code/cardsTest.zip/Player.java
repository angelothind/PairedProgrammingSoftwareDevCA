import java.util.ArrayList;
import java.util.Random;

// object to represent each player in the game.
public class Player {
    // current cards
    Hand hand;
    // winning number
    private int preference;
    // relevant decks
    private Deck drawDeck;
    private Deck discardDeck;

    // constructor
    Player(int preference, Deck drawDeck, Deck discardDeck,Hand hand){
        this.discardDeck = discardDeck;
        this.preference = preference;
        this.drawDeck = drawDeck;
        this.hand = hand;
    }

    // getters
    public Hand getHand() {
        return hand;
    }
    
    public Deck getDiscardDeck() {
        return discardDeck;
    }
    
    public int getPreference() {
        return preference;
    }
    
    public Deck getDrawDeck() {
        return drawDeck;
    }

    // other methods
    // adds a given card to the hand
    public void draw(Card drawnCard){
        this.hand.addCard(drawnCard);
    }

    // removes a random card from the hand which is not the preferred card
    public Card discard() {
        // getting all non preferred cards indexes
        ArrayList<Integer> disCards = new ArrayList<>();
        ArrayList<Card> cards = this.hand.getCards();
        for (Card card : cards){
            if (card.getValue() != getPreference()) {
                disCards.add(cards.indexOf(card));
            }
        }

        // edge case where there is only one disCard
        if (disCards.size() == 1){
            Card discarded = this.hand.removeCard(disCards.get(0));
            return discarded;
        }
        // randomly choosing a card to disard
        Random random = new Random();
        int randomIndex = random.nextInt(disCards.size() - 1);

        // removing chosen card from hand and returning said card
        Card discarded = this.hand.removeCard(disCards.get(randomIndex));
        return discarded;
    }

    // checks if this player has 4 preferred cards
    public boolean hasWon(){
        // loops through each card to check if it is preference
        boolean won = true;
        for (Card card: hand.getCards()){
            if(card.getValue() != preference){
                won = false;
            }
            if(won == false){
                break;
            }
        }
        return won;
    }
}
