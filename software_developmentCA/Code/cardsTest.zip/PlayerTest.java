import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;

class PlayerTest {
    @Test
    public void getHandTest(){
        // creating mock hand and assigning it to player
        // creating mock cards and hand
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        // creating mock player
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);
        
        // checking if works with normal hand
        assertEquals(hand1, player1.getHand());
    }

    @Test
    public void getDiscardDeckTest(){
        // creating mock player
        Hand hand1 = new Hand();
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);
        
        // checking if return correctly
        assertEquals(discardDeck, player1.getDiscardDeck());
    }

    @Test
    public void getPreferenceTest(){
        // creating mock player
        Hand hand1 = new Hand();
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);
        
        // checking if return correctly
        assertEquals(1, player1.getPreference());
    }

    @Test
    public void getDrawDeckTest(){
        // creating mock player
        Hand hand1 = new Hand();
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);
        
        // checking if return correctly
        assertEquals(drawDeck, player1.getDrawDeck());
    }

    @Test
    public void drawTest(){
        // creating mock objects
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Card card5 = new Card(5);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);
        
        // checking if adds card to hand as intended
        player1.draw(card5);
        hand1.addCard(card5);
        assertEquals(hand1, player1.getHand());
    }

    @Test
    public void discardTest(){
        // creating mock objects
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Card card5 = new Card(5);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        hand1.addCard(card5);
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);

        // test if work correctly with normal circumstances (not all cards are favourable or non favourable)
        Card[] validOutputs = {card2, card3, card4, card5};
        assertTrue(Arrays.asList(validOutputs).contains(player1.discard()));

        // no cards are favourable (no need to test all cards favourable as game will have ended if that is true)
        hand1.removeCard(0);
        hand1.addCard(card2);
        Player player2 = new Player(1, drawDeck, discardDeck, hand1);
        assertTrue(Arrays.asList(validOutputs).contains(player2.discard()));
    }
    
    @Test
    public void hasWonTest(){
        // creating mock objects
        Card card1 = new Card(1);
        Card card2 = new Card(1);
        Card card3 = new Card(1);
        Card card4 = new Card(1);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);

        // test if works with winning hand
        assertTrue(player1.hasWon());

        // test if works with losing hand
        Card card5 = new Card(4);
        Card card6 = new Card(2);
        Card card7 = new Card(3);
        Card card8 = new Card(4);
        Hand hand2 = new Hand();
        hand2.addCard(card5);
        hand2.addCard(card6);
        hand2.addCard(card7);
        hand2.addCard(card8);
        Player player2 = new Player(1, drawDeck, discardDeck, hand2);
        assertTrue(!player2.hasWon());

        // test if works 1 away
        Hand hand3 = new Hand();
        hand3.addCard(card1);
        hand3.addCard(card2);
        hand3.addCard(card3);
        hand3.addCard(card5);
        Player player3 = new Player(1, drawDeck, discardDeck, hand3);
        assertTrue(!player3.hasWon());
    }
}