import java.util.ArrayList;

// represents all deck which players draw and discard to.
public class Deck implements CardCollections {
    // attributes
    ArrayList<Card> deck = new ArrayList<>();
    int deckId;

    // constructor
    Deck(int deckId){
        this.deckId = deckId;
    }

    // getters
    public int getDeckId() {
        return deckId;
    }

    public ArrayList<Card> getDeck() {
        return deck;
    }

    // other methods
    // adds a card to the "bottom" of the deck (the end of the list)
    @Override
    public void addCard(Card card) {
        deck.add(card);
    }

    // draws a card from the "top" of the deck (the start of the list)
    @Override
    public Card removeCard() {
        if (deck.size() == 0){
            return null;
        }
        Card drawnCard = deck.get(0);
        deck.remove(0);
        return drawnCard;
    }
}
