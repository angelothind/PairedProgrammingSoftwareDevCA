import java.util.ArrayList;
// represents the cards in the players hand
public class Hand{
    // attributes
    private ArrayList<Card> cardList = new ArrayList<>();

    // getters
    public ArrayList<Card> getCards() {
        return cardList;
    }

    // other methods
    public void addCard(Card card) {
        cardList.add(card);
    }

    // removes a card at a set index
    public Card removeCard(int index){
        // input validation
        if (index > cardList.size() - 1 || index < 0){
            return null; 
        }
        
        Card card = cardList.get(index);
        cardList.remove(index);
        return card;
    }
}
