import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

class CardGameTest {
    // name of pack is hard coded into tests if you change the pack name but don't update it here it will not work.
    @Test
    public void createPackTest(){
        // reading pack file and converting into a list of numbers
        String filePath = "pack.txt";
        ArrayList<Integer> numbers = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
            while ((line = br.readLine()) != null) {
                try {
                    int number = Integer.parseInt(line.trim());
                    numbers.add(number);
                } catch (NumberFormatException e) {
                    System.err.println("Skipping invalid line: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + filePath + ". Please check the file path and try again.");
        } catch (IOException e) {
            System.err.println("An error occurred while reading the file: " + filePath + ". " + e.getMessage());
        }

        // reversing the numbers gotten from pack file as if you deal out cards from the pack it will come out reversed.
        Collections.reverse(numbers);;
        ArrayList<Integer> givenPackValues = new ArrayList<>();

        // accessing method using reflection then reading values of cards in pack generated and comparing to expected.
        try {
            Method method = CardGame.class.getDeclaredMethod("createPack", String.class);
            method.setAccessible(true);
            Pack pack = (Pack) method.invoke(null, filePath);
            for (int i=0; i < 32; i++){
                givenPackValues.add(pack.removeCard().getValue());
            }

            assertEquals(numbers, givenPackValues);
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void validatePackTest(){
        // create mock objects
        // create mock players list
        ArrayList<Player> mockPlayers = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            Player player = new Player(i + 1, null, null, null);
            mockPlayers.add(player);
        }
        // pack that is valid
        Pack pack1 = new Pack();
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        for (int i = 0; i < 8; i++){
            pack1.addCard(card1);
            pack1.addCard(card2);
            pack1.addCard(card3);
            pack1.addCard(card4);
        }

        // pack that is not valid because it has too many cards
        Pack pack2 = new Pack();
        for (int i = 0; i < 10; i++){
            pack2.addCard(card1);
            pack2.addCard(card2);
            pack2.addCard(card3);
            pack2.addCard(card4);
        }

        // pack that is not valid because it has too few cards
        Pack pack3 = new Pack();
        for (int i = 0; i < 5; i++){
            pack3.addCard(card1);
            pack3.addCard(card2);
            pack3.addCard(card3);
            pack3.addCard(card4);
        }

        // pack that is not valid because not every player can win
        Pack pack4 = new Pack();
        for (int i = 0; i < 3; i++){
            pack4.addCard(card1);
            pack4.addCard(card2);
            pack4.addCard(card3);
            pack4.addCard(card4);
        }
        for (int i = 0; i < 5; i++){
            pack4.addCard(card1);
            pack4.addCard(card2);
            pack4.addCard(card3);
            pack4.addCard(card3);
        }
        
        try {
            // setting players
            Field playersField = CardGame.class.getDeclaredField("players");
            playersField.setAccessible(true);
            playersField.set(null, mockPlayers);

            // invoking the method
            Method method = CardGame.class.getDeclaredMethod("validatePack", Pack.class);
            method.setAccessible(true);
            Boolean bool1 = (Boolean) method.invoke(null, pack1);
            Boolean bool2 = (Boolean) method.invoke(null, pack2);
            Boolean bool3 = (Boolean) method.invoke(null, pack3);
            Boolean bool4 = (Boolean) method.invoke(null, pack4);

            // checking output is correct for each
            assertTrue(bool1 && !bool2 && !bool3 && !bool4);
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException | NoSuchFieldException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void playerDiscardsTest(){
        // setting up mock objects
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Card card5 = new Card(5);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        hand1.addCard(card5);
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);
        
        try {
            // invoking method using reflection
            Method method = CardGame.class.getDeclaredMethod("playerDiscards", Player.class);
            method.setAccessible(true);
            Card cardOutput = (Card) method.invoke(null, player1);

            // card has been added to discard deck
            assertTrue(discardDeck.getDeck().size() == 1);

            // card has been removed from player hand
            assertTrue(player1.getHand().getCards().size() == 4);

            // card added to discard deck matches card output by function
            Card[] validOutputs = {card2, card3, card4, card5};
            assertTrue(Arrays.asList(validOutputs).contains(cardOutput));
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void playerDrawsTest(){
        // setting up mock objects
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Card card5 = new Card(5);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        Deck drawDeck = new Deck(0);
        drawDeck.addCard(card5);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);

        try {
            // invoking method using reflection
            Method method = CardGame.class.getDeclaredMethod("playerDraws", Player.class);
            method.setAccessible(true);
            Card cardOutput = (Card) method.invoke(null, player1);

            // check if card is taken from deck
            assertTrue(drawDeck.getDeck().size() == 0);

            // check if card is added to hand and the card is the same as the one taken from the deck
            assertTrue(player1.getHand().getCards().size() == 5 && cardOutput == card5);

        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void hasPlayerWonTest(){
        // create mock objects
        // hand
        Card card1 = new Card(1);
        Hand hand1 = new Hand();
        for (int i=0; i < 4; i++){
            hand1.addCard(card1);
        }
        
        // situation where 1 player is winning
        ArrayList<Player> mockPlayers = new ArrayList<>();
        Player player1 = new Player(1, null, null, hand1);
        mockPlayers.add(player1);
        for (int i = 1; i < 4; i++) {
            Player player = new Player(i + 1, null, null, hand1);
            mockPlayers.add(player);
        }

        // situation where no one is winning
        Card card0 = new Card(0);
        Hand hand2 = new Hand();
        for (int i=0; i < 4; i++){
            hand2.addCard(card0);
        }
        ArrayList<Player> mockPlayers2 = new ArrayList<>();
        for (int i = 1; i < 4; i++) {
            Player player = new Player(i + 1, null, null, hand2);
            mockPlayers2.add(player);
        }
        try {
            // setting players
            Field playersField = CardGame.class.getDeclaredField("players");
            playersField.setAccessible(true);
            playersField.set(null, mockPlayers);

            // invoking the method using reflection
            Method method = CardGame.class.getDeclaredMethod("hasPlayerWon");
            method.setAccessible(true);
            Object[] output = (Object[]) method.invoke(null);

            // checking win correctly identified
            Boolean boolObject = (Boolean) output[0];
            boolean gameOver = boolObject;
            Player winningPlayer = (Player) output[1];
            assertTrue(gameOver);
            assertTrue(winningPlayer == player1);

            // setting players
            playersField = CardGame.class.getDeclaredField("players");
            playersField.setAccessible(true);
            playersField.set(null, mockPlayers2);

            // invoking the method using reflection
            output = (Object[]) method.invoke(null);

            // checking win correctly identified
            boolObject = (Boolean) output[0];
            gameOver = boolObject;
            assertTrue(!gameOver);
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException | NoSuchFieldException e) {
            e.printStackTrace();
        }
        // Stated in spec don't have to handle situation where 2 people
    }

    @Test
    public void logCurrentHandTest(){
        // clearing the test text file
        File file = new File("player1_output_test.txt");
        try (FileWriter writer = new FileWriter(file)) {
            writer.write("");
            System.out.println("File has been cleared.");
        } catch (IOException e) {
            e.printStackTrace();
        }
        // making mock objects
        // output files
        // Create a list of mock files for output
        ArrayList<File> mockOutputFiles = new ArrayList<>();
        mockOutputFiles.add(new File("player1_output_test.txt"));
        mockOutputFiles.add(new File("player2_output_test.txt"));
        mockOutputFiles.add(new File("player3_output_test.txt"));
        mockOutputFiles.add(new File("player4_output_test.txt"));

        // make hand 
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        
        // make player
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);
        
        String expectedOutput = "Player1's current hand is 1 2 3 4 ";

        try {
            // setting output files
            Field outputFiles = CardGame.class.getDeclaredField("outputFiles");
            outputFiles.setAccessible(true);
            outputFiles.set(null, mockOutputFiles);

            // invoking method 
            Method method = CardGame.class.getDeclaredMethod("logCurrentHand", Player.class);
            method.setAccessible(true);
            method.invoke(null, player1);

            // reading from the file 
            // Create a FileReader and BufferedReader to read the file
            FileReader fileReader = new FileReader("player1_output_test.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            // Read the first line
            String firstLine = bufferedReader.readLine();
            bufferedReader.close();

            // Output the first line
            assertTrue(expectedOutput.equals(firstLine));

        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException | NoSuchFieldException | IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void logDrawnCardTest(){
        // clearing the test text file
        File file = new File("player1_output_test.txt");
        try (FileWriter writer = new FileWriter(file)) {
            writer.write("");
        } catch (IOException e) {
            e.printStackTrace();
        }
        // making mock objects
        // output files
        // Create a list of mock files for output
        ArrayList<File> mockOutputFiles = new ArrayList<>();
        mockOutputFiles.add(new File("player1_output_test.txt"));
        mockOutputFiles.add(new File("player2_output_test.txt"));
        mockOutputFiles.add(new File("player3_output_test.txt"));
        mockOutputFiles.add(new File("player4_output_test.txt"));

        // make hand 
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Card card5 = new Card(5);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        
        // make player
        Deck drawDeck = new Deck(0);
        drawDeck.addCard(card5);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);
        
        String expectedOutput ="Player1 drew the card 5.";

        try {
            // setting output files
            Field outputFiles = CardGame.class.getDeclaredField("outputFiles");
            outputFiles.setAccessible(true);
            outputFiles.set(null, mockOutputFiles);

            // drawing a card then logging it
            Method method = CardGame.class.getDeclaredMethod("playerDraws", Player.class);
            method.setAccessible(true);
            method.invoke(null, player1);
            method = CardGame.class.getDeclaredMethod("logDrawnCard", Player.class);
            method.setAccessible(true);
            method.invoke(null, player1);

            // reading from the file 
            // Create a FileReader and BufferedReader to read the file
            FileReader fileReader = new FileReader("player1_output_test.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            // Read the first line
            String firstLine = bufferedReader.readLine();
            bufferedReader.close();

            // Output the first line
            assertTrue(expectedOutput.equals(firstLine));

        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException | NoSuchFieldException | IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void logDisCardTest(){
        // clearing the test text file
        File file = new File("player1_output_test.txt");
        try (FileWriter writer = new FileWriter(file)) {
            writer.write("");
        } catch (IOException e) {
            e.printStackTrace();
        }
        // making mock objects
        // output files
        // Create a list of mock files for output
        ArrayList<File> mockOutputFiles = new ArrayList<>();
        mockOutputFiles.add(new File("player1_output_test.txt"));
        mockOutputFiles.add(new File("player2_output_test.txt"));
        mockOutputFiles.add(new File("player3_output_test.txt"));
        mockOutputFiles.add(new File("player4_output_test.txt"));

        // make hand 
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Card card5 = new Card(5);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        hand1.addCard(card5);
        
        // make player
        Deck drawDeck = new Deck(0);
        Deck discardDeck = new Deck(1);
        Player player1 = new Player(1, drawDeck, discardDeck, hand1);
        
        String expectedOutput ="Player1 discarded the card 5.";

        try {
            // setting output files
            Field outputFiles = CardGame.class.getDeclaredField("outputFiles");
            outputFiles.setAccessible(true);
            outputFiles.set(null, mockOutputFiles);

            // discarding a card then logging it
            Method method = CardGame.class.getDeclaredMethod("logDisCard", Player.class);
            method.setAccessible(true);
            method.invoke(null, player1);
            method = CardGame.class.getDeclaredMethod("logDisCard", Player.class);
            method.setAccessible(true);
            method.invoke(null, player1);

            // reading from the file 
            // Create a FileReader and BufferedReader to read the file
            FileReader fileReader = new FileReader("player1_output_test.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            // Read the first line
            String firstLine = bufferedReader.readLine();
            bufferedReader.close();

            // Output the first line
            assertTrue(expectedOutput.equals(firstLine));

        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException | NoSuchFieldException | IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void logGameEndTest(){
        // clearing the test text file
         File file = new File("player1_output_test.txt");
         try (FileWriter writer = new FileWriter(file)) {
             writer.write("");
         } catch (IOException e) {
             e.printStackTrace();
         }
        // clearing the test text file
        File file2 = new File("player2_output_test.txt");
        try (FileWriter writer = new FileWriter(file2)) {
            writer.write("");
        } catch (IOException e) {
            e.printStackTrace();
        }
        // setting up mock objects
        // hand
        Card card1 = new Card(1);
        Hand hand1 = new Hand();
        for (int i=0; i < 4; i++){
            hand1.addCard(card1);
        }

        // 4 output files
        // Create a list of mock files for output
        ArrayList<File> mockOutputFiles = new ArrayList<>();
        mockOutputFiles.add(new File("player1_output_test.txt"));
        mockOutputFiles.add(new File("player2_output_test.txt"));
        mockOutputFiles.add(new File("player3_output_test.txt"));
        mockOutputFiles.add(new File("player4_output_test.txt"));

        // situation where current thread player in winning
        String expectedOutput1 ="Player1 wins.";
        String expectedOutput2 ="Player1 exits.";
        String expectedOutput3 ="Player1 final hand: 1 1 1 1 ";

        // situation where current player isn't winning
        Player player2 = new Player(2, null, null, hand1);
        String expectedOutput4 ="Player1 has informed player2 that player1 has won.";
        String expectedOutput5 ="Player2 exits.";
        String expectedOutput6 ="Player2 final hand: 1 1 1 1 ";
        Player player1 = new Player(1, null, null, hand1);
        try {
            // setting output files
            Field outputFiles = CardGame.class.getDeclaredField("outputFiles");
            outputFiles.setAccessible(true);
            outputFiles.set(null, mockOutputFiles);

            // invoking the method
            Method method = CardGame.class.getDeclaredMethod("logGameEnd", Player.class, Player.class);
            method.setAccessible(true);
            method.invoke(null, player1, player1);

            // reading from the file 
            // Create a FileReader and BufferedReader to read the file
            FileReader fileReader = new FileReader("player1_output_test.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            // Read the output
            String firstLine = bufferedReader.readLine();
            String secondLine = bufferedReader.readLine();
            String thirdLine = bufferedReader.readLine();
            bufferedReader.close();

            assertTrue(expectedOutput1.equals(firstLine) && expectedOutput2.equals(secondLine) && expectedOutput3.equals(thirdLine));

            // setting output files
            outputFiles = CardGame.class.getDeclaredField("outputFiles");
            outputFiles.setAccessible(true);
            outputFiles.set(null, mockOutputFiles);

            // invoking the method
            method.invoke(null, player2, player1);
            
            // reading from the file 
            // Create a FileReader and BufferedReader to read the file
            fileReader = new FileReader("player2_output_test.txt");
            bufferedReader = new BufferedReader(fileReader);

            // Read the output
            firstLine = bufferedReader.readLine();
            secondLine = bufferedReader.readLine();
            thirdLine = bufferedReader.readLine();
            bufferedReader.close();

            assertTrue(expectedOutput4.equals(firstLine) && expectedOutput5.equals(secondLine) && expectedOutput6.equals(thirdLine));
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException | NoSuchFieldException | IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void endGameTest(){
        // set mock objects
        // player
        Player player1 = new Player(1, null, null, null);
        Player player2 = new Player(2, null, null, null);

        // gameEndArray
        Object[] gameEndArray = {true, player1};
        try {
            Method method = CardGame.class.getDeclaredMethod("endGame", Player.class, Object[].class);
            method.setAccessible(true);
            // Create a ByteArrayOutputStream to capture the output
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            PrintStream printStream = new PrintStream(outputStream);
            
            // Redirect System.out to capture the output
            System.setOut(printStream);
            
            // invoking method
            method.invoke(null, player1, gameEndArray);

            // Convert the captured output to a string
            String capturedOutput = outputStream.toString().trim();

            // Assert that the output is what we expect
            assertEquals("Player1 wins.", capturedOutput);

            // next situation (non winning player runs method)
            // Create a ByteArrayOutputStream to capture the output
            outputStream = new ByteArrayOutputStream();
            printStream = new PrintStream(outputStream);
            
            // Redirect System.out to capture the output
            System.setOut(printStream);
            
            // make sure winning message is not sent to terminal 
            method.invoke(null, player2, gameEndArray);

            // Convert the captured output to a string
            capturedOutput = outputStream.toString().trim();

            assertEquals(capturedOutput, "");
        } catch (NoSuchMethodException | SecurityException | IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    // testing gameLoop method doesn't make much sense as it exclusively contains other methods which have all been unit tested.
}