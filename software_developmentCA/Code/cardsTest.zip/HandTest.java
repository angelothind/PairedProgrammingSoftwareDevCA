import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class HandTest {
    // similar to deck you cannot test getCards without using add card and vise versa
    @Test
    public void getCardsTest(){
        // creating mock cards and hand
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Hand hand1 = new Hand();

        // check with a simple hand
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        ArrayList<Card> expectedOutput = new ArrayList<>();
        expectedOutput.add(card1);
        expectedOutput.add(card2);
        expectedOutput.add(card3);
        expectedOutput.add(card4);
        assertEquals(expectedOutput, hand1.getCards());

        // checking with complex cards
        Card card5 = new Card(2000);
        Card card6 = new Card(-3);
        Card card7 = new Card(1);
        Card card8 = new Card(0);
        Hand hand2 = new Hand();
        hand2.addCard(card5);
        hand2.addCard(card6);
        hand2.addCard(card7);
        hand2.addCard(card8);
        ArrayList<Card> expectedOutput2 = new ArrayList<>();
        expectedOutput2.add(card5);
        expectedOutput2.add(card6);
        expectedOutput2.add(card7);
        expectedOutput2.add(card8);
        assertEquals(expectedOutput2, hand2.getCards());

        // checking with multiple of the same card in one hand (this checks same values as well)
        Hand hand3 = new Hand();
        hand3.addCard(card1);
        hand3.addCard(card2);
        hand3.addCard(card3);
        hand3.addCard(card1);
        ArrayList<Card> expectedOutput3 = new ArrayList<>();
        expectedOutput3.add(card1);
        expectedOutput3.add(card2);
        expectedOutput3.add(card3);
        expectedOutput3.add(card1);
        assertEquals(expectedOutput3, hand3.getCards());

        // checking with an empty hand
        Hand hand4 = new Hand();
        ArrayList<Card> expectedOutput4 = new ArrayList<>();
        assertEquals(expectedOutput4, hand4.getCards());
    }

    @Test
    public void addCardTest(){
        // making mock cards and hands
        // creating mock cards and hand
        Card card1 = new Card(1);
        Card card2 = new Card(1000);
        Card card3 = new Card(-100);
        Card card4 = new Card(0);
        Hand hand1 = new Hand();

        // adding a variety of cards
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);
        ArrayList<Card> expectedOutput = new ArrayList<>();
        expectedOutput.add(card1);
        expectedOutput.add(card2);
        expectedOutput.add(card3);
        expectedOutput.add(card4);
        assertEquals(expectedOutput, hand1.getCards());
    }

    @Test
    public void removeCardTest(){
        // making mock cards and hands
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        Card card4 = new Card(4);
        Hand hand1 = new Hand();
        hand1.addCard(card1);
        hand1.addCard(card2);
        hand1.addCard(card3);
        hand1.addCard(card4);

        // checking to see if removing from a specific index works
        // last card
        assertEquals(card4, hand1.removeCard(3));

        // first card
        hand1.addCard(card4);
        assertEquals(card1, hand1.removeCard(0));

        // other
        assertEquals(card3, hand1.removeCard(1));

        // checking to see if you can remove an item from an empty list or out of index range
        Hand hand2 = new Hand();
        assertEquals(null, hand2.removeCard(2));
        assertEquals(null, hand2.removeCard(-2));
    }
}