import java.util.ArrayList;

// represents the input pack which is used to deal out all hands and decks to players.
public class Pack implements CardCollections{
    // attributes
    ArrayList<Card> pack = new ArrayList<>();   

    // methods
    @Override
    public void addCard(Card card) {
        pack.add(card);
    }

    @Override
    public Card removeCard() {
        if (pack.size() == 0){
            return null;
        }
        Card dealtCard = pack.getLast();
        pack.removeLast();
        return dealtCard;
    }

    // returns the entire list of all cards in the pack
    public ArrayList<Card> getPack() {
        return pack;
    }
}
