// object to represent all card objects in game.
public class Card {
    private int value;

    Card(int value){
        this.value = value;
    }

    int getValue(){
        return value;
    }
}
