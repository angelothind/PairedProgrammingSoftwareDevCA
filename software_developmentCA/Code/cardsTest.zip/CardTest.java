import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CardTest {
    @Test
    public void getValueTest(){
        // checking if works with a variety of numbers
        Card card1 = new Card(0);
        Card card2 = new Card(1000);
        Card card3 = new Card(-100);
        Card card4 = new Card(1);

        assertEquals(0,card1.getValue());
        assertEquals(1000,card2.getValue());
        assertEquals(-100,card3.getValue());
        assertEquals(1,card4.getValue());
    }
}